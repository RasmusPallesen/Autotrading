@echo off
title Trading Agent - Research
color 0E

echo.
echo  ============================================
echo   Trading Agent - Research Agent
echo  ============================================
echo.

:: ── Set your credentials here ─────────────────────────────────────────────────
set ALPACA_API_KEY=YOUR_ALPACA_API_KEY
set ALPACA_SECRET_KEY=YOUR_ALPACA_SECRET_KEY
set ALPACA_PAPER=true
set ANTHROPIC_API_KEY=YOUR_ANTHROPIC_API_KEY
set DATABASE_URL=YOUR_RAILWAY_DATABASE_URL

:: ── Research agent credentials ────────────────────────────────────────────────
set NEWSAPI_KEY=YOUR_NEWSAPI_KEY
set REDDIT_CLIENT_ID=YOUR_REDDIT_CLIENT_ID
set REDDIT_CLIENT_SECRET=YOUR_REDDIT_CLIENT_SECRET
set GMAIL_ADDRESS=YOUR_GMAIL_ADDRESS
set GMAIL_APP_PASSWORD=YOUR_GMAIL_APP_PASSWORD

:: ── Settings ──────────────────────────────────────────────────────────────────
set RESEARCH_INTERVAL_SECONDS=900
set CONVICTION_THRESHOLD=0.70
:: ──────────────────────────────────────────────────────────────────────────────

call .venv\Scripts\activate

echo  Starting research agent... (Ctrl+C to stop)
echo  Runs every 15 minutes and emails rasmus.pallesen@gmail.com on signals
echo.
python research/research_agent.py

echo.
echo  Research agent stopped.
pause
