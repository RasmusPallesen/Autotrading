"""
Research agent main loop.
Runs on a schedule, collects data, analyses it, and sends alerts.
Run alongside main.py: python research_agent.py
"""

import logging
import os
import signal
import sys
import time
from datetime import datetime, timezone

import config
from research.collector import fetch_news, fetch_sec_filings, fetch_reddit
from research.analyst import ResearchAnalyst
from research.emailer import send_alert

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/research.log", encoding="utf-8"),
    ],
)
logger = logging.getLogger("research_agent")

# How often the research agent runs (default: every 15 minutes)
RESEARCH_INTERVAL = int(os.getenv("RESEARCH_INTERVAL_SECONDS", "900"))
CONVICTION_THRESHOLD = float(os.getenv("CONVICTION_THRESHOLD", "0.70"))


def run_research_cycle(analyst: ResearchAnalyst):
    """One full research cycle: collect -> analyse -> alert."""
    logger.info("=== Research cycle starting ===")
    symbols = config.watchlist.stocks

    # 1. Collect from all sources
    news_items = fetch_news(
        symbols,
        api_key=os.getenv("NEWSAPI_KEY", ""),
    )
    sec_items = fetch_sec_filings(symbols)
    reddit_items = fetch_reddit(
        symbols,
        client_id=os.getenv("REDDIT_CLIENT_ID", ""),
        client_secret=os.getenv("REDDIT_CLIENT_SECRET", ""),
    )

    all_items = news_items + sec_items + reddit_items
    logger.info(
        "Collected %d items — news=%d, SEC=%d, Reddit=%d",
        len(all_items), len(news_items), len(sec_items), len(reddit_items),
    )

    if not all_items:
        logger.warning("No research items collected this cycle")
        return

    # 2. Analyse with Claude
    reports = analyst.analyse_all(all_items, symbols)

    high_conviction = [r for r in reports if r.conviction >= CONVICTION_THRESHOLD]
    logger.info(
        "Analysis complete — %d reports, %d high-conviction",
        len(reports), len(high_conviction),
    )

    for r in reports:
        logger.info(
            "[%s] %s | conviction=%.0f%% | action=%s | %s",
            r.symbol, r.overall_sentiment, r.conviction * 100,
            r.recommended_action, r.summary[:80],
        )

    # 3. Send email for high-conviction signals
    if high_conviction:
        send_alert(high_conviction)

    logger.info("=== Research cycle complete ===")


def main():
    logger.info("Research Agent starting up")
    logger.info("  Interval: %ds (%d min)", RESEARCH_INTERVAL, RESEARCH_INTERVAL // 60)
    logger.info("  Conviction threshold: %.0f%%", CONVICTION_THRESHOLD * 100)
    logger.info("  Watchlist: %s", config.watchlist.stocks)

    analyst = ResearchAnalyst(config.anthropic)

    running = True
    def _shutdown(sig, frame):
        nonlocal running
        logger.warning("Shutdown signal — finishing current cycle.")
        running = False

    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    while running:
        try:
            run_research_cycle(analyst)
        except Exception as e:
            logger.exception("Unhandled error in research cycle: %s", e)

        if running:
            logger.info("Sleeping %ds until next research cycle...", RESEARCH_INTERVAL)
            time.sleep(RESEARCH_INTERVAL)

    logger.info("Research agent shut down cleanly.")


if __name__ == "__main__":
    main()
