"""
Market scanner: discovers opportunity across the broad market.
Finds top gainers, unusual volume spikes, and 52-week high breakouts.
Runs each research cycle and feeds discoveries to the research agent.
"""

import logging
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import List, Optional

import requests

logger = logging.getLogger(__name__)


@dataclass
class ScannerHit:
    symbol: str
    company_name: str
    price: float
    change_pct: float       # % change today
    volume: float
    avg_volume: float
    volume_ratio: float     # volume / avg_volume
    reason: str             # Why it was flagged
    score: float            # 0-1 priority score


class MarketScanner:
    """
    Scans the broad market for unusual activity using Alpaca's screener
    and Yahoo Finance as fallback.
    """

    def __init__(self, alpaca_api_key: str, alpaca_secret_key: str, paper: bool = True):
        self.api_key = alpaca_api_key
        self.secret_key = alpaca_secret_key
        self.base = "https://paper-api.alpaca.markets" if paper else "https://api.alpaca.markets"
        self.data_base = "https://data.alpaca.markets"

    def _alpaca_headers(self) -> dict:
        return {
            "APCA-API-KEY-ID": self.api_key,
            "APCA-API-SECRET-KEY": self.secret_key,
        }

    def scan(self, max_results: int = 20) -> List[ScannerHit]:
        """
        Run all scans and return ranked list of hits.
        Deduplicates across scans, highest score wins.
        """
        all_hits: dict = {}  # symbol -> ScannerHit

        for hit in self._scan_top_gainers():
            if hit.symbol not in all_hits or hit.score > all_hits[hit.symbol].score:
                all_hits[hit.symbol] = hit

        for hit in self._scan_unusual_volume():
            if hit.symbol not in all_hits:
                all_hits[hit.symbol] = hit
            else:
                # Merge — combine reasons, keep higher score
                existing = all_hits[hit.symbol]
                merged_reason = existing.reason + " + " + hit.reason
                merged_score = min(existing.score + 0.15, 1.0)
                all_hits[hit.symbol] = ScannerHit(
                    symbol=existing.symbol,
                    company_name=existing.company_name,
                    price=existing.price,
                    change_pct=existing.change_pct,
                    volume=existing.volume,
                    avg_volume=existing.avg_volume,
                    volume_ratio=existing.volume_ratio,
                    reason=merged_reason,
                    score=merged_score,
                )

        ranked = sorted(all_hits.values(), key=lambda h: h.score, reverse=True)
        results = ranked[:max_results]

        logger.info(
            "Market scanner found %d hits (top gainers + unusual volume)",
            len(results),
        )
        for h in results[:5]:
            logger.info(
                "  [%s] %+.1f%% | vol %.1fx | score=%.2f | %s",
                h.symbol, h.change_pct, h.volume_ratio, h.score, h.reason,
            )

        return results

    def _scan_top_gainers(self) -> List[ScannerHit]:
        """Fetch today's top gaining stocks from Alpaca screener."""
        hits = []
        try:
            resp = requests.get(
                f"{self.data_base}/v1beta1/screener/stocks/most-actives",
                headers=self._alpaca_headers(),
                params={"by": "change_percent", "top": 30},
                timeout=10,
            )
            resp.raise_for_status()
            data = resp.json().get("most_actives", [])

            for item in data:
                symbol = item.get("symbol", "")
                change_pct = float(item.get("change_percent", 0))
                price = float(item.get("price", 0))
                volume = float(item.get("volume", 0))
                trade_count = int(item.get("trade_count", 0))

                if change_pct < 3.0:  # Only care about 3%+ moves
                    continue
                if price < 1.0:       # Skip penny stocks
                    continue

                # Score: bigger move + higher price = better
                score = min((change_pct / 30.0) * 0.7 + (min(price, 500) / 500) * 0.3, 1.0)

                reason = f"Top gainer +{change_pct:.1f}% today"
                if change_pct > 10:
                    reason = f"STRONG gainer +{change_pct:.1f}% today"
                if change_pct > 20:
                    reason = f"EXPLOSIVE move +{change_pct:.1f}% today -- investigate catalyst"

                hits.append(ScannerHit(
                    symbol=symbol,
                    company_name=item.get("symbol", symbol),
                    price=price,
                    change_pct=change_pct,
                    volume=volume,
                    avg_volume=volume,  # Alpaca screener doesn't give avg
                    volume_ratio=1.0,
                    reason=reason,
                    score=score,
                ))

        except Exception as e:
            logger.warning("Top gainers scan failed: %s", e)
            hits = self._scan_gainers_yahoo()

        return hits

    def _scan_gainers_yahoo(self) -> List[ScannerHit]:
        """Fallback: fetch top gainers from Yahoo Finance."""
        hits = []
        try:
            resp = requests.get(
                "https://query1.finance.yahoo.com/v1/finance/screener/predefined/saved",
                params={"scrIds": "day_gainers", "count": 25, "formatted": "false"},
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=10,
            )
            resp.raise_for_status()
            quotes = resp.json().get("finance", {}).get("result", [{}])[0].get("quotes", [])

            for q in quotes:
                symbol = q.get("symbol", "")
                change_pct = float(q.get("regularMarketChangePercent", 0))
                price = float(q.get("regularMarketPrice", 0))
                volume = float(q.get("regularMarketVolume", 0))
                avg_volume = float(q.get("averageDailyVolume3Month", volume or 1))

                if change_pct < 3.0 or price < 1.0:
                    continue

                score = min((change_pct / 30.0) * 0.7 + (min(price, 500) / 500) * 0.3, 1.0)
                hits.append(ScannerHit(
                    symbol=symbol,
                    company_name=q.get("shortName", symbol),
                    price=price,
                    change_pct=change_pct,
                    volume=volume,
                    avg_volume=avg_volume,
                    volume_ratio=volume / avg_volume if avg_volume else 1.0,
                    reason=f"Top gainer +{change_pct:.1f}% (Yahoo Finance)",
                    score=score,
                ))
        except Exception as e:
            logger.warning("Yahoo Finance fallback scan failed: %s", e)

        return hits

    def _scan_unusual_volume(self) -> List[ScannerHit]:
        """Fetch stocks with unusually high volume from Alpaca screener."""
        hits = []
        try:
            resp = requests.get(
                f"{self.data_base}/v1beta1/screener/stocks/most-actives",
                headers=self._alpaca_headers(),
                params={"by": "volume", "top": 30},
                timeout=10,
            )
            resp.raise_for_status()
            data = resp.json().get("most_actives", [])

            for item in data:
                symbol = item.get("symbol", "")
                price = float(item.get("price", 0))
                change_pct = float(item.get("change_percent", 0))
                volume = float(item.get("volume", 0))

                if price < 5.0:
                    continue
                if abs(change_pct) < 1.0:
                    continue

                score = min(abs(change_pct) / 20.0 * 0.6 + 0.3, 0.85)
                direction = "up" if change_pct > 0 else "down"
                hits.append(ScannerHit(
                    symbol=symbol,
                    company_name=symbol,
                    price=price,
                    change_pct=change_pct,
                    volume=volume,
                    avg_volume=volume,
                    volume_ratio=2.0,  # Flagged as unusual by screener
                    reason=f"Unusual volume with {change_pct:+.1f}% move {direction}",
                    score=score,
                ))

        except Exception as e:
            logger.warning("Unusual volume scan failed: %s", e)

        return hits

    def get_symbol_detail(self, symbol: str) -> Optional[dict]:
        """Fetch basic info about a discovered symbol for context."""
        try:
            resp = requests.get(
                f"https://query1.finance.yahoo.com/v10/finance/quoteSummary/{symbol}",
                params={"modules": "summaryProfile,price"},
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=5,
            )
            resp.raise_for_status()
            result = resp.json().get("quoteSummary", {}).get("result", [{}])[0]
            profile = result.get("summaryProfile", {})
            price = result.get("price", {})
            return {
                "sector": profile.get("sector", "Unknown"),
                "industry": profile.get("industry", "Unknown"),
                "description": profile.get("longBusinessSummary", "")[:300],
                "market_cap": price.get("marketCap", {}).get("raw", 0),
                "company_name": price.get("longName", symbol),
            }
        except Exception:
            return None
